"use client"

import { useState, useEffect } from "react"
import InvoiceForm from "@/components/InvoiceForm"
import BrandingForm from "@/components/BrandingForm"
import InvoicePreview from "@/components/InvoicePreview"
import CustomDownloadButton from "@/components/CustomDownloadButton"
import SocialMediaSharing from "@/components/SocialMediaSharing"
import { Toaster } from "@/components/ui/toaster"
import type { InvoiceData, BrandingData } from "@/types"

// Default invoice data
const defaultInvoiceData: InvoiceData = {
  invoiceNumber: "",
  date: new Date().toISOString().split("T")[0],
  dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
  clientName: "",
  clientEmail: "",
  clientAddress: "",
  clientTaxId: "",
  items: [{ description: "", quantity: 1, unitPrice: 0 }],
  additionalCharges: [],
  notes: "",
  currency: "USD",
  taxRate: 0,
  discountType: "percentage",
  discountValue: 0,
}

// Default branding data
const defaultBrandingData: BrandingData = {
  businessName: "",
  businessEmail: "",
  businessAddress: "",
  businessPhone: "",
  businessTaxId: "",
  bankDetails: "",
  logo: null,
  primaryColor: "#4F46E5",
  watermark: {
    enabled: false,
    text: "PAID",
    opacity: 10,
    angle: -30,
  },
}

export default function Home() {
  const [invoiceData, setInvoiceData] = useState<InvoiceData>(defaultInvoiceData)
  const [brandingData, setBrandingData] = useState<BrandingData>(defaultBrandingData)
  const [isClient, setIsClient] = useState(false)

  // Set isClient to true when component mounts (client-side only)
  useEffect(() => {
    setIsClient(true)
  }, [])

  // Load saved data from localStorage only on the client side
  useEffect(() => {
    if (isClient) {
      try {
        const savedInvoiceData = localStorage.getItem("invoiceData")
        const savedBrandingData = localStorage.getItem("brandingData")

        if (savedInvoiceData) {
          setInvoiceData(JSON.parse(savedInvoiceData))
        }

        if (savedBrandingData) {
          const parsedBranding = JSON.parse(savedBrandingData)
          setBrandingData({
            ...parsedBranding,
            logo: parsedBranding.logo, // Logo is stored as a data URL
            watermark: parsedBranding.watermark || {
              enabled: false,
              text: "PAID",
              opacity: 10,
              angle: -30,
            },
            businessTaxId: parsedBranding.businessTaxId || "",
          })
        }
      } catch (error) {
        console.error("Error loading saved data:", error)
        // If there's an error loading data, we'll just use the defaults
      }
    }
  }, [isClient])

  // Save data to localStorage whenever it changes (client-side only)
  useEffect(() => {
    if (isClient) {
      try {
        localStorage.setItem("invoiceData", JSON.stringify(invoiceData))
      } catch (error) {
        console.error("Error saving invoice data:", error)
      }
    }
  }, [invoiceData, isClient])

  useEffect(() => {
    if (isClient) {
      try {
        // We need to handle the logo specially since it's a File object
        const brandingForStorage = {
          ...brandingData,
          logo: brandingData.logo, // Store logo as data URL
        }
        localStorage.setItem("brandingData", JSON.stringify(brandingForStorage))
      } catch (error) {
        console.error("Error saving branding data:", error)
      }
    }
  }, [brandingData, isClient])

  // Calculate subtotal, discount, tax, and total
  const calculateTotals = () => {
    const subtotal = invoiceData.items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0)

    // Calculate discount
    let discountAmount = 0
    if (invoiceData.discountType === "percentage") {
      discountAmount = subtotal * (invoiceData.discountValue / 100)
    } else {
      discountAmount = Math.min(invoiceData.discountValue, subtotal) // Ensure discount doesn't exceed subtotal
    }

    // Calculate additional charges total
    const additionalChargesTotal = invoiceData.additionalCharges.reduce((sum, charge) => sum + charge.amount, 0)

    // Calculate tax on subtotal minus discount plus additional charges
    const taxableAmount = Math.max(0, subtotal - discountAmount + additionalChargesTotal)
    const tax = taxableAmount * (invoiceData.taxRate / 100)

    // Calculate final total
    const total = taxableAmount + tax

    return {
      subtotal,
      discountAmount,
      additionalChargesTotal,
      tax,
      total,
    }
  }

  const { subtotal, discountAmount, additionalChargesTotal, tax, total } = calculateTotals()

  // Generate a base filename for exports
  const baseFileName = `Invoice-${invoiceData.invoiceNumber || "new"}`

  return (
    <main className="min-h-screen p-4 md:p-8 bg-gray-50">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold text-gray-900 mb-8">Invoice Generator</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Forms Section - Always on the left */}
          <div className="space-y-8">
            <BrandingForm brandingData={brandingData} setBrandingData={setBrandingData} />
            <InvoiceForm invoiceData={invoiceData} setInvoiceData={setInvoiceData} />

            <div className="lg:hidden">
              <div className="flex flex-wrap gap-3">
                <CustomDownloadButton
                  invoiceData={invoiceData}
                  brandingData={brandingData}
                  subtotal={subtotal}
                  discountAmount={discountAmount}
                  additionalChargesTotal={additionalChargesTotal}
                  tax={tax}
                  total={total}
                  fileName={baseFileName}
                />
                <SocialMediaSharing invoiceData={invoiceData} brandingData={brandingData} total={total} />
              </div>
            </div>
          </div>

          {/* Preview Section - Always on the right on large screens */}
          <div className="hidden lg:block">
            <div className="sticky top-8">
              <InvoicePreview
                invoiceData={invoiceData}
                brandingData={brandingData}
                subtotal={subtotal}
                discountAmount={discountAmount}
                additionalChargesTotal={additionalChargesTotal}
                tax={tax}
                total={total}
              />

              <div className="mt-4 flex flex-wrap gap-3">
                <CustomDownloadButton
                  invoiceData={invoiceData}
                  brandingData={brandingData}
                  subtotal={subtotal}
                  discountAmount={discountAmount}
                  additionalChargesTotal={additionalChargesTotal}
                  tax={tax}
                  total={total}
                  fileName={baseFileName}
                />
                <SocialMediaSharing invoiceData={invoiceData} brandingData={brandingData} total={total} />
              </div>
            </div>
          </div>
        </div>
      </div>
      <Toaster />
    </main>
  )
}

