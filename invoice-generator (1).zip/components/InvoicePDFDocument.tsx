"use client"
import { Document, Page, Text, View, StyleSheet, Image, Canvas } from "@react-pdf/renderer"
import type { InvoiceData, BrandingData } from "@/types"

interface InvoicePDFProps {
  invoiceData: InvoiceData
  brandingData: BrandingData
  subtotal: number
  discountAmount: number
  additionalChargesTotal: number
  tax: number
  total: number
}

// Helper function to format currency
const formatCurrency = (amount: number, currencyCode: string) => {
  const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currencyCode,
    minimumFractionDigits: 2,
  })
  return formatter.format(amount)
}

// Watermark component for PDF
const Watermark = ({ text, opacity, angle }: { text: string; opacity: number; angle: number }) => {
  return (
    <Canvas
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
      }}
      paint={(painter, canvas) => {
        const { width, height } = canvas

        // Set up the watermark style
        painter.fillOpacity(opacity / 100)
        painter.fillColor("#cccccc")
        painter.fontSize(72)
        painter.textAlign("center")

        // Save the current state
        painter.save()

        // Move to center, rotate, then draw text
        painter.translate(width / 2, height / 2)
        painter.rotate(angle)
        painter.fillText(text, 0, 0)

        // Restore the state
        painter.restore()
      }}
    />
  )
}

export default function InvoicePDFDocument({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
}: InvoicePDFProps) {
  // Create styles with dynamic brand color
  const styles = StyleSheet.create({
    page: {
      padding: 30,
      fontSize: 12,
      fontFamily: "Helvetica",
      position: "relative",
    },
    header: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 30,
    },
    businessInfo: {
      marginBottom: 10,
    },
    businessName: {
      fontSize: 20,
      fontWeight: "bold",
      color: brandingData.primaryColor,
      marginBottom: 5,
    },
    businessDetails: {
      fontSize: 10,
      color: "#666",
    },
    businessTaxId: {
      fontSize: 10,
      color: "#666",
      marginTop: 2,
    },
    invoiceInfo: {
      backgroundColor: "#f5f5f5",
      padding: 10,
      borderRadius: 5,
    },
    invoiceTitle: {
      fontSize: 16,
      fontWeight: "bold",
      color: brandingData.primaryColor,
      marginBottom: 5,
    },
    invoiceDetails: {
      flexDirection: "row",
      justifyContent: "space-between",
      fontSize: 10,
      marginBottom: 3,
    },
    clientSection: {
      marginBottom: 30,
    },
    sectionTitle: {
      fontSize: 10,
      textTransform: "uppercase",
      color: "#666",
      marginBottom: 5,
    },
    clientName: {
      fontSize: 14,
      fontWeight: "bold",
      marginBottom: 3,
    },
    clientDetails: {
      fontSize: 10,
      color: "#444",
    },
    clientTaxId: {
      fontSize: 10,
      color: "#444",
      marginTop: 3,
    },
    table: {
      marginBottom: 20,
    },
    tableHeader: {
      flexDirection: "row",
      borderBottomWidth: 1,
      borderBottomColor: "#ddd",
      paddingBottom: 5,
      fontWeight: "bold",
    },
    tableRow: {
      flexDirection: "row",
      borderBottomWidth: 1,
      borderBottomColor: "#eee",
      paddingVertical: 8,
    },
    description: {
      flex: 3,
    },
    quantity: {
      flex: 1,
      textAlign: "right",
    },
    unitPrice: {
      flex: 1,
      textAlign: "right",
    },
    amount: {
      flex: 1,
      textAlign: "right",
    },
    additionalChargesTable: {
      marginBottom: 20,
    },
    additionalChargeRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      borderBottomWidth: 1,
      borderBottomColor: "#eee",
      paddingVertical: 5,
    },
    totalsSection: {
      alignItems: "flex-end",
      marginBottom: 30,
    },
    totalsRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      width: 200,
      paddingVertical: 3,
    },
    discountRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      width: 200,
      paddingVertical: 3,
      color: "#e53e3e", // Red color for discount
    },
    totalsBorder: {
      borderBottomWidth: 1,
      borderBottomColor: "#ddd",
    },
    totalLabel: {
      fontWeight: "bold",
    },
    grandTotal: {
      fontWeight: "bold",
      fontSize: 14,
    },
    bankDetails: {
      borderTopWidth: 1,
      borderTopColor: "#ddd",
      paddingTop: 10,
      marginBottom: 20,
    },
    notes: {
      borderTopWidth: 1,
      borderTopColor: "#ddd",
      paddingTop: 10,
    },
    notesTitle: {
      fontSize: 10,
      textTransform: "uppercase",
      color: "#666",
      marginBottom: 5,
    },
    notesText: {
      fontSize: 10,
      color: "#444",
    },
    logo: {
      width: 120,
      height: 50,
      objectFit: "contain",
      marginBottom: 10,
    },
  })

  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Watermark */}
        {brandingData.watermark.enabled && brandingData.watermark.text && (
          <Watermark
            text={brandingData.watermark.text}
            opacity={brandingData.watermark.opacity}
            angle={brandingData.watermark.angle}
          />
        )}

        {/* Header */}
        <View style={styles.header}>
          <View style={styles.businessInfo}>
            {brandingData.logo && (
              <Image src={(brandingData.logo as string) || "/placeholder.svg"} style={styles.logo} />
            )}
            <Text style={styles.businessName}>{brandingData.businessName || "Your Business Name"}</Text>
            {brandingData.businessAddress && <Text style={styles.businessDetails}>{brandingData.businessAddress}</Text>}
            {brandingData.businessEmail && <Text style={styles.businessDetails}>{brandingData.businessEmail}</Text>}
            {brandingData.businessPhone && <Text style={styles.businessDetails}>{brandingData.businessPhone}</Text>}
            {brandingData.businessTaxId && (
              <Text style={styles.businessTaxId}>GSTIN/VAT: {brandingData.businessTaxId}</Text>
            )}
          </View>

          <View style={styles.invoiceInfo}>
            <Text style={styles.invoiceTitle}>INVOICE</Text>
            <View style={styles.invoiceDetails}>
              <Text>Invoice Number:</Text>
              <Text>{invoiceData.invoiceNumber || "INV-001"}</Text>
            </View>
            <View style={styles.invoiceDetails}>
              <Text>Date:</Text>
              <Text>{invoiceData.date}</Text>
            </View>
            <View style={styles.invoiceDetails}>
              <Text>Due Date:</Text>
              <Text>{invoiceData.dueDate}</Text>
            </View>
          </View>
        </View>

        {/* Client Info */}
        <View style={styles.clientSection}>
          <Text style={styles.sectionTitle}>Bill To:</Text>
          <Text style={styles.clientName}>{invoiceData.clientName}</Text>
          {invoiceData.clientEmail && <Text style={styles.clientDetails}>{invoiceData.clientEmail}</Text>}
          {invoiceData.clientAddress && <Text style={styles.clientDetails}>{invoiceData.clientAddress}</Text>}
          {invoiceData.clientTaxId && <Text style={styles.clientTaxId}>GSTIN/VAT: {invoiceData.clientTaxId}</Text>}
        </View>

        {/* Items Table */}
        <View style={styles.table}>
          <View style={styles.tableHeader}>
            <Text style={styles.description}>Description</Text>
            <Text style={styles.quantity}>Qty</Text>
            <Text style={styles.unitPrice}>Unit Price</Text>
            <Text style={styles.amount}>Amount</Text>
          </View>

          {invoiceData.items.map((item, index) => (
            <View key={index} style={styles.tableRow}>
              <Text style={styles.description}>{item.description || "Item description"}</Text>
              <Text style={styles.quantity}>{item.quantity}</Text>
              <Text style={styles.unitPrice}>{formatCurrency(item.unitPrice, invoiceData.currency)}</Text>
              <Text style={styles.amount}>{formatCurrency(item.quantity * item.unitPrice, invoiceData.currency)}</Text>
            </View>
          ))}
        </View>

        {/* Additional Charges */}
        {invoiceData.additionalCharges && invoiceData.additionalCharges.length > 0 && (
          <View style={styles.additionalChargesTable}>
            <Text style={styles.sectionTitle}>Additional Charges:</Text>

            {invoiceData.additionalCharges.map((charge, index) => (
              <View key={index} style={styles.additionalChargeRow}>
                <Text>{charge.description || "Additional charge"}</Text>
                <Text>{formatCurrency(charge.amount, invoiceData.currency)}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Totals */}
        <View style={styles.totalsSection}>
          <View style={styles.totalsRow}>
            <Text>Subtotal:</Text>
            <Text>{formatCurrency(subtotal, invoiceData.currency)}</Text>
          </View>

          {discountAmount > 0 && (
            <View style={styles.discountRow}>
              <Text>
                Discount {invoiceData.discountType === "percentage" ? `(${invoiceData.discountValue}%)` : ""}:
              </Text>
              <Text>-{formatCurrency(discountAmount, invoiceData.currency)}</Text>
            </View>
          )}

          {additionalChargesTotal > 0 && (
            <View style={styles.totalsRow}>
              <Text>Additional Charges:</Text>
              <Text>{formatCurrency(additionalChargesTotal, invoiceData.currency)}</Text>
            </View>
          )}

          <View style={[styles.totalsRow, styles.totalsBorder]}>
            <Text>Tax ({invoiceData.taxRate}%):</Text>
            <Text>{formatCurrency(tax, invoiceData.currency)}</Text>
          </View>

          <View style={styles.totalsRow}>
            <Text style={styles.totalLabel}>Total:</Text>
            <Text style={styles.grandTotal}>{formatCurrency(total, invoiceData.currency)}</Text>
          </View>
        </View>

        {/* Bank Details */}
        {brandingData.bankDetails && (
          <View style={styles.bankDetails}>
            <Text style={styles.notesTitle}>Payment Details:</Text>
            <Text style={styles.notesText}>{brandingData.bankDetails}</Text>
          </View>
        )}

        {/* Notes */}
        {invoiceData.notes && (
          <View style={styles.notes}>
            <Text style={styles.notesTitle}>Notes:</Text>
            <Text style={styles.notesText}>{invoiceData.notes}</Text>
          </View>
        )}
      </Page>
    </Document>
  )
}

