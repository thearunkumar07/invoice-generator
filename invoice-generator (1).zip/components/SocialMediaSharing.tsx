"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Share2, Mail, Copy, Check, Twitter, Facebook, Linkedin } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import type { InvoiceData, BrandingData } from "@/types"
import { toast } from "@/components/ui/use-toast"

interface SocialMediaSharingProps {
  invoiceData: InvoiceData
  brandingData: BrandingData
  total: number
}

export default function SocialMediaSharing({ invoiceData, brandingData, total }: SocialMediaSharingProps) {
  const [copied, setCopied] = useState(false)
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
  }, [])

  // Create a shareable message about the invoice
  const createShareMessage = () => {
    const businessName = brandingData.businessName || "Our business"
    const clientName = invoiceData.clientName || "our client"
    const invoiceNumber = invoiceData.invoiceNumber || "new invoice"

    return `${businessName} has created invoice #${invoiceNumber} for ${clientName}. Total amount: ${new Intl.NumberFormat(
      "en-US",
      {
        style: "currency",
        currency: invoiceData.currency,
      },
    ).format(total)}.`
  }

  // Generate sharing URLs for different platforms
  const shareMessage = createShareMessage()
  const encodedMessage = encodeURIComponent(shareMessage)

  // Only create URLs on the client side
  const twitterUrl = isClient ? `https://twitter.com/intent/tweet?text=${encodedMessage}` : "#"
  const facebookUrl = isClient
    ? `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}&quote=${encodedMessage}`
    : "#"
  const linkedinUrl = isClient
    ? `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(window.location.href)}&title=${encodeURIComponent("Invoice")}&summary=${encodedMessage}`
    : "#"
  const emailUrl = `mailto:?subject=${encodeURIComponent(`Invoice #${invoiceData.invoiceNumber || ""}`)}&body=${encodedMessage}`

  const copyToClipboard = () => {
    if (!isClient) return

    try {
      navigator.clipboard.writeText(shareMessage)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
      toast({
        title: "Copied to clipboard",
        description: "The invoice details have been copied to your clipboard.",
      })
    } catch (error) {
      console.error("Failed to copy text: ", error)
      toast({
        title: "Failed to copy",
        description: "Could not copy to clipboard. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <Share2 className="h-4 w-4" />
          <span>Share</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <div className="space-y-4">
          <h3 className="font-medium text-sm">Share this invoice</h3>

          <div className="flex flex-col gap-2">
            <a
              href={twitterUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-md transition-colors"
            >
              <Twitter className="h-5 w-5 text-[#1DA1F2]" />
              <span>Share on Twitter</span>
            </a>

            <a
              href={facebookUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-md transition-colors"
            >
              <Facebook className="h-5 w-5 text-[#4267B2]" />
              <span>Share on Facebook</span>
            </a>

            <a
              href={linkedinUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-md transition-colors"
            >
              <Linkedin className="h-5 w-5 text-[#0077B5]" />
              <span>Share on LinkedIn</span>
            </a>

            <a href={emailUrl} className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-md transition-colors">
              <Mail className="h-5 w-5 text-gray-600" />
              <span>Share via Email</span>
            </a>

            <button
              onClick={copyToClipboard}
              className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded-md transition-colors text-left"
            >
              {copied ? <Check className="h-5 w-5 text-green-500" /> : <Copy className="h-5 w-5 text-gray-600" />}
              <span>{copied ? "Copied!" : "Copy to clipboard"}</span>
            </button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  )
}

