"use client"

import type { InvoiceData, BrandingData } from "@/types"
import { Card, CardContent } from "@/components/ui/card"

interface InvoicePreviewProps {
  invoiceData: InvoiceData
  brandingData: BrandingData
  subtotal: number
  discountAmount: number
  additionalChargesTotal: number
  tax: number
  total: number
}

// Helper function to format currency
const formatCurrency = (amount: number, currencyCode: string) => {
  const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currencyCode,
    minimumFractionDigits: 2,
  })
  return formatter.format(amount)
}

export default function InvoicePreview({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
}: InvoicePreviewProps) {
  return (
    <Card className="bg-white shadow-lg">
      <CardContent className="p-8 relative">
        {/* Watermark */}
        {brandingData.watermark.enabled && brandingData.watermark.text && (
          <div
            className="absolute inset-0 flex items-center justify-center overflow-hidden pointer-events-none z-0"
            aria-hidden="true"
          >
            <div
              className="text-6xl md:text-8xl font-bold text-gray-100 transform"
              style={{
                opacity: brandingData.watermark.opacity / 100,
                transform: `rotate(${brandingData.watermark.angle}deg)`,
                position: "absolute",
                width: "150%",
                textAlign: "center",
              }}
            >
              {brandingData.watermark.text}
            </div>
          </div>
        )}

        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start mb-8 relative z-10">
          <div className="mb-4 md:mb-0">
            {brandingData.logo && (
              <img
                src={(brandingData.logo as string) || "/placeholder.svg"}
                alt="Business Logo"
                className="h-16 mb-2 object-contain"
              />
            )}
            <h1 className="text-2xl font-bold" style={{ color: brandingData.primaryColor }}>
              {brandingData.businessName || "Your Business Name"}
            </h1>
            <div className="text-sm text-gray-600 mt-1">
              {brandingData.businessAddress && <p>{brandingData.businessAddress}</p>}
              {brandingData.businessEmail && <p>{brandingData.businessEmail}</p>}
              {brandingData.businessPhone && <p>{brandingData.businessPhone}</p>}
              {brandingData.businessTaxId && (
                <p>
                  <span className="font-medium">GSTIN/VAT:</span> {brandingData.businessTaxId}
                </p>
              )}
            </div>
          </div>

          <div className="bg-gray-100 p-4 rounded-md">
            <h2 className="text-xl font-bold mb-2" style={{ color: brandingData.primaryColor }}>
              INVOICE
            </h2>
            <div className="grid grid-cols-2 gap-x-4 text-sm">
              <span className="font-medium">Invoice Number:</span>
              <span>{invoiceData.invoiceNumber || "INV-001"}</span>

              <span className="font-medium">Date:</span>
              <span>{invoiceData.date}</span>

              <span className="font-medium">Due Date:</span>
              <span>{invoiceData.dueDate}</span>
            </div>
          </div>
        </div>

        {/* Client Info */}
        <div className="mb-8 relative z-10">
          <h3 className="text-sm font-medium uppercase text-gray-500 mb-2">Bill To:</h3>
          <div className="text-lg font-medium">{invoiceData.clientName}</div>
          {invoiceData.clientEmail && <div>{invoiceData.clientEmail}</div>}
          {invoiceData.clientAddress && (
            <div className="text-gray-600 whitespace-pre-line">{invoiceData.clientAddress}</div>
          )}
          {invoiceData.clientTaxId && (
            <div className="text-gray-600 mt-1">
              <span className="font-medium">GSTIN/VAT:</span> {invoiceData.clientTaxId}
            </div>
          )}
        </div>

        {/* Items Table */}
        <div className="mb-6 overflow-x-auto relative z-10">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b-2 border-gray-200">
                <th className="py-2 text-left">Description</th>
                <th className="py-2 text-right">Qty</th>
                <th className="py-2 text-right">Unit Price</th>
                <th className="py-2 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              {invoiceData.items.map((item, index) => (
                <tr key={index} className="border-b border-gray-100">
                  <td className="py-3">{item.description || "Item description"}</td>
                  <td className="py-3 text-right">{item.quantity}</td>
                  <td className="py-3 text-right">{formatCurrency(item.unitPrice, invoiceData.currency)}</td>
                  <td className="py-3 text-right">
                    {formatCurrency(item.quantity * item.unitPrice, invoiceData.currency)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Additional Charges */}
        {invoiceData.additionalCharges.length > 0 && (
          <div className="mb-6 relative z-10">
            <h3 className="text-sm font-medium uppercase text-gray-500 mb-2">Additional Charges:</h3>
            <table className="w-full border-collapse">
              <tbody>
                {invoiceData.additionalCharges.map((charge, index) => (
                  <tr key={index} className="border-b border-gray-100">
                    <td className="py-2">{charge.description || "Additional charge"}</td>
                    <td className="py-2 text-right">{formatCurrency(charge.amount, invoiceData.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Totals */}
        <div className="flex justify-end mb-8 relative z-10">
          <div className="w-full md:w-64">
            <div className="flex justify-between py-2">
              <span>Subtotal:</span>
              <span>{formatCurrency(subtotal, invoiceData.currency)}</span>
            </div>

            {discountAmount > 0 && (
              <div className="flex justify-between py-2 text-red-600">
                <span>
                  Discount {invoiceData.discountType === "percentage" ? `(${invoiceData.discountValue}%)` : ""}:
                </span>
                <span>-{formatCurrency(discountAmount, invoiceData.currency)}</span>
              </div>
            )}

            {additionalChargesTotal > 0 && (
              <div className="flex justify-between py-2">
                <span>Additional Charges:</span>
                <span>{formatCurrency(additionalChargesTotal, invoiceData.currency)}</span>
              </div>
            )}

            <div className="flex justify-between py-2">
              <span>Tax ({invoiceData.taxRate}%):</span>
              <span>{formatCurrency(tax, invoiceData.currency)}</span>
            </div>

            <div className="flex justify-between py-2 border-t border-gray-200 font-bold text-lg">
              <span>Total:</span>
              <span>{formatCurrency(total, invoiceData.currency)}</span>
            </div>
          </div>
        </div>

        {/* Bank Details */}
        {brandingData.bankDetails && (
          <div className="border-t border-gray-200 pt-4 mb-4 relative z-10">
            <h3 className="text-sm font-medium uppercase text-gray-500 mb-2">Payment Details:</h3>
            <p className="text-gray-600 whitespace-pre-line">{brandingData.bankDetails}</p>
          </div>
        )}

        {/* Notes */}
        {invoiceData.notes && (
          <div className="border-t border-gray-200 pt-4 relative z-10">
            <h3 className="text-sm font-medium uppercase text-gray-500 mb-2">Notes:</h3>
            <p className="text-gray-600 whitespace-pre-line">{invoiceData.notes}</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

