"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"
import type { InvoiceData, BrandingData } from "@/types"

interface CustomPDFButtonProps {
  invoiceData: InvoiceData
  brandingData: BrandingData
  subtotal: number
  discountAmount: number
  additionalChargesTotal: number
  tax: number
  total: number
  fileName: string
}

export default function CustomPDFButton({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
  fileName,
}: CustomPDFButtonProps) {
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGeneratePDF = async () => {
    setIsGenerating(true)

    try {
      // Dynamically import the PDF generation module only when needed
      const { generatePDF } = await import("@/lib/pdf-generator")

      // Generate and download the PDF
      await generatePDF({
        invoiceData,
        brandingData,
        subtotal,
        discountAmount,
        additionalChargesTotal,
        tax,
        total,
        fileName,
      })
    } catch (error) {
      console.error("Error generating PDF:", error)
      alert("There was an error generating the PDF. Please try again.")
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <Button
      onClick={handleGeneratePDF}
      disabled={isGenerating}
      className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
    >
      <Download className="h-4 w-4 mr-2" />
      {isGenerating ? "Generating PDF..." : "Download PDF"}
    </Button>
  )
}

