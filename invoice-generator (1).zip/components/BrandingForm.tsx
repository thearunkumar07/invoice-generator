"use client"

import type React from "react"

import { useState, useRef } from "react"
import type { BrandingData } from "@/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Upload, X } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"

interface BrandingFormProps {
  brandingData: BrandingData
  setBrandingData: React.Dispatch<React.SetStateAction<BrandingData>>
}

export default function BrandingForm({ brandingData, setBrandingData }: BrandingFormProps) {
  const [logoPreview, setLogoPreview] = useState<string | null>(brandingData.logo as string)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setBrandingData((prev) => ({ ...prev, [name]: value }))
  }

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Check file size (limit to 2MB)
    if (file.size > 2 * 1024 * 1024) {
      alert("Logo file size must be less than 2MB")
      return
    }

    // Create a preview URL
    const reader = new FileReader()
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string
      setLogoPreview(dataUrl)
      setBrandingData((prev) => ({ ...prev, logo: dataUrl }))
    }
    reader.readAsDataURL(file)
  }

  const removeLogo = () => {
    setLogoPreview(null)
    setBrandingData((prev) => ({ ...prev, logo: null }))
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleWatermarkChange = (field: string, value: string | number | boolean) => {
    setBrandingData((prev) => ({
      ...prev,
      watermark: {
        ...prev.watermark,
        [field]: value,
      },
    }))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Business Branding</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Business Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="businessName">Business Name</Label>
            <Input
              id="businessName"
              name="businessName"
              value={brandingData.businessName}
              onChange={handleInputChange}
              placeholder="Your Business Name"
            />
          </div>
          <div>
            <Label htmlFor="businessEmail">Business Email</Label>
            <Input
              id="businessEmail"
              name="businessEmail"
              value={brandingData.businessEmail}
              onChange={handleInputChange}
              placeholder="business@example.com"
            />
          </div>
          <div>
            <Label htmlFor="businessPhone">Business Phone</Label>
            <Input
              id="businessPhone"
              name="businessPhone"
              value={brandingData.businessPhone}
              onChange={handleInputChange}
              placeholder="+1 (555) 123-4567"
            />
          </div>
          <div>
            <Label htmlFor="businessAddress">Business Address</Label>
            <Input
              id="businessAddress"
              name="businessAddress"
              value={brandingData.businessAddress}
              onChange={handleInputChange}
              placeholder="Your Business Address"
            />
          </div>
          <div className="col-span-1 md:col-span-2">
            <Label htmlFor="businessTaxId">GSTIN/VAT (if applicable)</Label>
            <Input
              id="businessTaxId"
              name="businessTaxId"
              value={brandingData.businessTaxId}
              onChange={handleInputChange}
              placeholder="Your tax identification number"
            />
          </div>
        </div>

        {/* Bank Details */}
        <div>
          <Label htmlFor="bankDetails">Bank Account Details</Label>
          <Textarea
            id="bankDetails"
            name="bankDetails"
            value={brandingData.bankDetails}
            onChange={handleInputChange}
            placeholder="Account Name: Your Business Name
Account Number: 123456789
Bank Name: Example Bank
SWIFT/BIC: EXAMPLEXXX
IBAN: XX00 0000 0000 0000 0000 0000"
            rows={4}
          />
        </div>

        {/* Watermark */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="watermark-enabled">Watermark</Label>
            <Switch
              id="watermark-enabled"
              checked={brandingData.watermark.enabled}
              onCheckedChange={(checked) => handleWatermarkChange("enabled", checked)}
            />
          </div>

          {brandingData.watermark.enabled && (
            <div className="space-y-4 pl-4 border-l-2 border-gray-200">
              <div>
                <Label htmlFor="watermark-text">Watermark Text</Label>
                <Input
                  id="watermark-text"
                  value={brandingData.watermark.text}
                  onChange={(e) => handleWatermarkChange("text", e.target.value)}
                  placeholder="PAID, DRAFT, CONFIDENTIAL, etc."
                />
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <Label htmlFor="watermark-opacity">Opacity: {brandingData.watermark.opacity}%</Label>
                </div>
                <Slider
                  id="watermark-opacity"
                  min={5}
                  max={50}
                  step={1}
                  value={[brandingData.watermark.opacity]}
                  onValueChange={(value) => handleWatermarkChange("opacity", value[0])}
                />
              </div>

              <div>
                <div className="flex justify-between mb-2">
                  <Label htmlFor="watermark-angle">Angle: {brandingData.watermark.angle}°</Label>
                </div>
                <Slider
                  id="watermark-angle"
                  min={-45}
                  max={45}
                  step={5}
                  value={[brandingData.watermark.angle]}
                  onValueChange={(value) => handleWatermarkChange("angle", value[0])}
                />
              </div>
            </div>
          )}
        </div>

        {/* Logo Upload */}
        <div>
          <Label htmlFor="logo">Business Logo</Label>
          <div className="mt-2 flex items-center gap-4">
            <input
              type="file"
              id="logo"
              ref={fileInputRef}
              accept="image/*"
              onChange={handleLogoUpload}
              className="hidden"
            />
            <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
              <Upload className="h-4 w-4 mr-2" /> Upload Logo
            </Button>

            {logoPreview && (
              <div className="relative">
                <img
                  src={logoPreview || "/placeholder.svg"}
                  alt="Logo preview"
                  className="h-16 w-auto object-contain border rounded p-1"
                />
                <button
                  type="button"
                  onClick={removeLogo}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            )}
          </div>
          <p className="text-sm text-gray-500 mt-1">Recommended: Square or landscape image, max 2MB</p>
        </div>

        {/* Brand Color */}
        <div>
          <Label htmlFor="primaryColor">Brand Color</Label>
          <div className="flex items-center gap-4 mt-2">
            <Input
              id="primaryColor"
              name="primaryColor"
              type="color"
              value={brandingData.primaryColor}
              onChange={handleInputChange}
              className="w-16 h-10 p-1"
            />
            <Input
              type="text"
              value={brandingData.primaryColor}
              onChange={handleInputChange}
              name="primaryColor"
              placeholder="#000000"
              className="w-32"
            />
            <div className="w-full h-10 rounded-md" style={{ backgroundColor: brandingData.primaryColor }} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

