"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Download, ChevronDown, FileText, FileJson, FileSpreadsheet, FileCode, File } from "lucide-react"
import type { InvoiceData, BrandingData } from "@/types"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"

interface CustomDownloadButtonProps {
  invoiceData: InvoiceData
  brandingData: BrandingData
  subtotal: number
  discountAmount: number
  additionalChargesTotal: number
  tax: number
  total: number
  fileName: string
}

type ExportFormat = "pdf" | "json" | "csv" | "html" | "text"

export default function CustomDownloadButton({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
  fileName,
}: CustomDownloadButtonProps) {
  const [isGenerating, setIsGenerating] = useState(false)
  const [selectedFormat, setSelectedFormat] = useState<ExportFormat>("pdf")

  const handleExport = async (format: ExportFormat) => {
    // Validate invoice data before export
    if (!invoiceData.invoiceNumber) {
      toast({
        title: "Missing invoice number",
        description: "Please enter an invoice number before exporting.",
        variant: "destructive",
      })
      return
    }

    if (!invoiceData.clientName) {
      toast({
        title: "Missing client information",
        description: "Please enter client name before exporting.",
        variant: "destructive",
      })
      return
    }

    if (invoiceData.items.some((item) => !item.description)) {
      toast({
        title: "Incomplete invoice items",
        description: "Please fill in all item descriptions before exporting.",
        variant: "destructive",
      })
      return
    }

    setSelectedFormat(format)
    setIsGenerating(true)

    try {
      // Dynamically import the export module only when needed
      const exportModule = await import("@/lib/export-formats")

      const exportFunctions = {
        pdf: exportModule.exportAsPDF,
        json: exportModule.exportAsJSON,
        csv: exportModule.exportAsCSV,
        html: exportModule.exportAsHTML,
        text: exportModule.exportAsText,
      }

      // Call the appropriate export function
      await exportFunctions[format]({
        invoiceData,
        brandingData,
        subtotal,
        discountAmount,
        additionalChargesTotal,
        tax,
        total,
        fileName: `Invoice-${invoiceData.invoiceNumber || "new"}`,
      })

      toast({
        title: "Export successful",
        description: `Your invoice has been exported as ${format.toUpperCase()}.`,
        variant: "default",
      })
    } catch (error) {
      console.error(`Error generating ${format.toUpperCase()}:`, error)
      toast({
        title: `Error generating ${format.toUpperCase()}`,
        description: "There was an error exporting your invoice. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const formatLabels: Record<ExportFormat, { label: string; icon: React.ReactNode }> = {
    pdf: {
      label: "PDF Document",
      icon: <FileText className="h-4 w-4 mr-2" />,
    },
    json: {
      label: "JSON Data",
      icon: <FileJson className="h-4 w-4 mr-2" />,
    },
    csv: {
      label: "CSV Spreadsheet",
      icon: <FileSpreadsheet className="h-4 w-4 mr-2" />,
    },
    html: {
      label: "HTML Document",
      icon: <FileCode className="h-4 w-4 mr-2" />,
    },
    text: {
      label: "Plain Text",
      icon: <File className="h-4 w-4 mr-2" />,
    },
  }

  return (
    <div className="flex">
      <Button
        onClick={() => handleExport(selectedFormat)}
        disabled={isGenerating}
        className="px-4 py-2 bg-green-600 text-white rounded-l-md hover:bg-green-700 transition-colors"
      >
        <Download className="h-4 w-4 mr-2" />
        {isGenerating ? `Generating ${selectedFormat.toUpperCase()}...` : `Download ${selectedFormat.toUpperCase()}`}
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="px-2 py-2 border-l-0 rounded-l-none rounded-r-md bg-green-600 hover:bg-green-700 text-white transition-colors"
            disabled={isGenerating}
          >
            <ChevronDown className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          {(Object.keys(formatLabels) as ExportFormat[]).map((format) => (
            <DropdownMenuItem key={format} onClick={() => handleExport(format)} className="flex items-center">
              {formatLabels[format].icon}
              {formatLabels[format].label}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}

