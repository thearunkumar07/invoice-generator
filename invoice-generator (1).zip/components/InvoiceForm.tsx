"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { InvoiceData, InvoiceItem, AdditionalCharge } from "@/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Trash2, Plus } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

interface InvoiceFormProps {
  invoiceData: InvoiceData
  setInvoiceData: React.Dispatch<React.SetStateAction<InvoiceData>>
}

const currencies = [
  { code: "USD", symbol: "$", name: "US Dollar" },
  { code: "EUR", symbol: "€", name: "Euro" },
  { code: "GBP", symbol: "£", name: "British Pound" },
  { code: "JPY", symbol: "¥", name: "Japanese Yen" },
  { code: "CAD", symbol: "C$", name: "Canadian Dollar" },
  { code: "AUD", symbol: "A$", name: "Australian Dollar" },
  { code: "INR", symbol: "₹", name: "Indian Rupee" },
]

export default function InvoiceForm({ invoiceData, setInvoiceData }: InvoiceFormProps) {
  // Get saved clients from localStorage
  const [savedClients, setSavedClients] = useState<string[]>([])
  const [isClient, setIsClient] = useState(false)

  // Set isClient to true when component mounts (client-side only)
  useEffect(() => {
    setIsClient(true)

    // Load saved clients from localStorage
    const saved = localStorage.getItem("savedClients")
    setSavedClients(saved ? JSON.parse(saved) : [])
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setInvoiceData((prev) => ({ ...prev, [name]: value }))
  }

  const handleNumberInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setInvoiceData((prev) => ({ ...prev, [name]: Number.parseFloat(value) || 0 }))
  }

  const handleCurrencyChange = (value: string) => {
    setInvoiceData((prev) => ({ ...prev, currency: value }))
  }

  const handleDiscountTypeChange = (value: "percentage" | "flat") => {
    setInvoiceData((prev) => ({ ...prev, discountType: value }))
  }

  const handleClientSelect = (clientName: string) => {
    if (!isClient) return

    // Find client details in localStorage
    const clientsData = localStorage.getItem("clientsData")
    if (clientsData) {
      const clients = JSON.parse(clientsData)
      const client = clients.find((c: any) => c.name === clientName)
      if (client) {
        setInvoiceData((prev) => ({
          ...prev,
          clientName: client.name,
          clientEmail: client.email || "",
          clientAddress: client.address || "",
          clientTaxId: client.taxId || "",
        }))
      }
    }
  }

  const saveCurrentClient = () => {
    if (!isClient || !invoiceData.clientName) return

    // Save client to localStorage if not already saved
    if (!savedClients.includes(invoiceData.clientName)) {
      const newSavedClients = [...savedClients, invoiceData.clientName]
      setSavedClients(newSavedClients)
      localStorage.setItem("savedClients", JSON.stringify(newSavedClients))

      // Save client details
      const clientsData = localStorage.getItem("clientsData")
      const clients = clientsData ? JSON.parse(clientsData) : []
      clients.push({
        name: invoiceData.clientName,
        email: invoiceData.clientEmail,
        address: invoiceData.clientAddress,
        taxId: invoiceData.clientTaxId,
      })
      localStorage.setItem("clientsData", JSON.stringify(clients))
    }
  }

  const handleItemChange = (index: number, field: keyof InvoiceItem, value: string | number) => {
    const newItems = [...invoiceData.items]

    if (field === "quantity" || field === "unitPrice") {
      newItems[index][field] = typeof value === "string" ? Number.parseFloat(value) || 0 : value
    } else {
      // @ts-ignore - TypeScript doesn't know that value is a string here
      newItems[index][field] = value
    }

    setInvoiceData((prev) => ({ ...prev, items: newItems }))
  }

  const addItem = () => {
    setInvoiceData((prev) => ({
      ...prev,
      items: [...prev.items, { description: "", quantity: 1, unitPrice: 0 }],
    }))
  }

  const removeItem = (index: number) => {
    if (invoiceData.items.length > 1) {
      const newItems = [...invoiceData.items]
      newItems.splice(index, 1)
      setInvoiceData((prev) => ({ ...prev, items: newItems }))
    }
  }

  // Additional Charges Handlers
  const handleAdditionalChargeChange = (index: number, field: keyof AdditionalCharge, value: string | number) => {
    const newCharges = [...invoiceData.additionalCharges]

    if (field === "amount") {
      newCharges[index][field] = typeof value === "string" ? Number.parseFloat(value) || 0 : value
    } else {
      // @ts-ignore - TypeScript doesn't know that value is a string here
      newCharges[index][field] = value
    }

    setInvoiceData((prev) => ({ ...prev, additionalCharges: newCharges }))
  }

  const addAdditionalCharge = () => {
    setInvoiceData((prev) => ({
      ...prev,
      additionalCharges: [...prev.additionalCharges, { description: "", amount: 0 }],
    }))
  }

  const removeAdditionalCharge = (index: number) => {
    const newCharges = [...invoiceData.additionalCharges]
    newCharges.splice(index, 1)
    setInvoiceData((prev) => ({ ...prev, additionalCharges: newCharges }))
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Invoice Details</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Invoice Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="invoiceNumber">Invoice Number</Label>
            <Input
              id="invoiceNumber"
              name="invoiceNumber"
              value={invoiceData.invoiceNumber}
              onChange={handleInputChange}
              placeholder="INV-001"
            />
          </div>
          <div>
            <Label htmlFor="date">Invoice Date</Label>
            <Input id="date" name="date" type="date" value={invoiceData.date} onChange={handleInputChange} />
          </div>
          <div>
            <Label htmlFor="dueDate">Due Date</Label>
            <Input id="dueDate" name="dueDate" type="date" value={invoiceData.dueDate} onChange={handleInputChange} />
          </div>
        </div>

        {/* Client Info */}
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-medium">Client Information</h3>
            {isClient && savedClients.length > 0 && (
              <Select onValueChange={handleClientSelect}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Select saved client" />
                </SelectTrigger>
                <SelectContent>
                  {savedClients.map((client) => (
                    <SelectItem key={client} value={client}>
                      {client}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="clientName">Client Name</Label>
              <Input
                id="clientName"
                name="clientName"
                value={invoiceData.clientName}
                onChange={handleInputChange}
                placeholder="Client Name"
              />
            </div>
            <div>
              <Label htmlFor="clientEmail">Client Email</Label>
              <Input
                id="clientEmail"
                name="clientEmail"
                value={invoiceData.clientEmail}
                onChange={handleInputChange}
                placeholder="client@example.com"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="clientAddress">Client Address</Label>
            <Textarea
              id="clientAddress"
              name="clientAddress"
              value={invoiceData.clientAddress}
              onChange={handleInputChange}
              placeholder="Street, City, State, ZIP"
              rows={2}
            />
          </div>

          <div>
            <Label htmlFor="clientTaxId">GSTIN/VAT (if applicable)</Label>
            <Input
              id="clientTaxId"
              name="clientTaxId"
              value={invoiceData.clientTaxId}
              onChange={handleInputChange}
              placeholder="Client's tax identification number"
            />
          </div>

          <Button
            type="button"
            variant="outline"
            onClick={saveCurrentClient}
            disabled={!invoiceData.clientName || !isClient}
          >
            Save Client for Future Use
          </Button>
        </div>

        {/* Currency and Tax */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="currency">Currency</Label>
            <Select value={invoiceData.currency} onValueChange={handleCurrencyChange}>
              <SelectTrigger id="currency">
                <SelectValue placeholder="Select currency" />
              </SelectTrigger>
              <SelectContent>
                {currencies.map((currency) => (
                  <SelectItem key={currency.code} value={currency.code}>
                    {currency.code} ({currency.symbol}) - {currency.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="taxRate">Tax Rate (%)</Label>
            <Input
              id="taxRate"
              name="taxRate"
              type="number"
              min="0"
              max="100"
              step="0.01"
              value={invoiceData.taxRate}
              onChange={handleNumberInputChange}
              placeholder="0.00"
            />
          </div>
        </div>

        {/* Discount */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Discount</h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Discount Type</Label>
              <RadioGroup
                value={invoiceData.discountType}
                onValueChange={(value) => handleDiscountTypeChange(value as "percentage" | "flat")}
                className="flex space-x-4 mt-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="percentage" id="percentage" />
                  <Label htmlFor="percentage">Percentage (%)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="flat" id="flat" />
                  <Label htmlFor="flat">Flat Amount</Label>
                </div>
              </RadioGroup>
            </div>
            <div>
              <Label htmlFor="discountValue">
                {invoiceData.discountType === "percentage" ? "Discount (%)" : "Discount Amount"}
              </Label>
              <Input
                id="discountValue"
                name="discountValue"
                type="number"
                min="0"
                step={invoiceData.discountType === "percentage" ? "1" : "0.01"}
                value={invoiceData.discountValue}
                onChange={handleNumberInputChange}
                placeholder="0"
              />
            </div>
          </div>
        </div>

        {/* Invoice Items */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Invoice Items</h3>

          {invoiceData.items.map((item, index) => (
            <div key={index} className="grid grid-cols-12 gap-2 items-end">
              <div className="col-span-12 sm:col-span-6">
                <Label htmlFor={`item-${index}-description`}>Description</Label>
                <Input
                  id={`item-${index}-description`}
                  value={item.description}
                  onChange={(e) => handleItemChange(index, "description", e.target.value)}
                  placeholder="Item description"
                />
              </div>
              <div className="col-span-5 sm:col-span-2">
                <Label htmlFor={`item-${index}-quantity`}>Qty</Label>
                <Input
                  id={`item-${index}-quantity`}
                  type="number"
                  min="1"
                  step="1"
                  value={item.quantity}
                  onChange={(e) => handleItemChange(index, "quantity", e.target.value)}
                />
              </div>
              <div className="col-span-5 sm:col-span-3">
                <Label htmlFor={`item-${index}-price`}>Unit Price</Label>
                <Input
                  id={`item-${index}-price`}
                  type="number"
                  min="0"
                  step="0.01"
                  value={item.unitPrice}
                  onChange={(e) => handleItemChange(index, "unitPrice", e.target.value)}
                />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeItem(index)}
                  disabled={invoiceData.items.length <= 1}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}

          <Button type="button" variant="outline" onClick={addItem} className="w-full">
            <Plus className="h-4 w-4 mr-2" /> Add Item
          </Button>
        </div>

        {/* Additional Charges */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Additional Charges</h3>

          {invoiceData.additionalCharges.length === 0 && (
            <p className="text-sm text-gray-500">No additional charges added yet.</p>
          )}

          {invoiceData.additionalCharges.map((charge, index) => (
            <div key={index} className="grid grid-cols-12 gap-2 items-end">
              <div className="col-span-12 sm:col-span-8">
                <Label htmlFor={`charge-${index}-description`}>Description</Label>
                <Input
                  id={`charge-${index}-description`}
                  value={charge.description}
                  onChange={(e) => handleAdditionalChargeChange(index, "description", e.target.value)}
                  placeholder="Charge description (e.g., Shipping, Handling)"
                />
              </div>
              <div className="col-span-10 sm:col-span-3">
                <Label htmlFor={`charge-${index}-amount`}>Amount</Label>
                <Input
                  id={`charge-${index}-amount`}
                  type="number"
                  min="0"
                  step="0.01"
                  value={charge.amount}
                  onChange={(e) => handleAdditionalChargeChange(index, "amount", e.target.value)}
                />
              </div>
              <div className="col-span-2 sm:col-span-1">
                <Button type="button" variant="ghost" size="icon" onClick={() => removeAdditionalCharge(index)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}

          <Button type="button" variant="outline" onClick={addAdditionalCharge} className="w-full">
            <Plus className="h-4 w-4 mr-2" /> Add Additional Charge
          </Button>
        </div>

        {/* Notes */}
        <div>
          <Label htmlFor="notes">Notes</Label>
          <Textarea
            id="notes"
            name="notes"
            value={invoiceData.notes}
            onChange={handleInputChange}
            placeholder="Payment terms, bank details, or any additional information"
            rows={3}
          />
        </div>
      </CardContent>
    </Card>
  )
}

