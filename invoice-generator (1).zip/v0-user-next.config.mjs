/** @type {import('next').NextConfig} */
const nextConfig = {
  // Transpile react-pdf to ensure it works correctly
  transpilePackages: ['@react-pdf/renderer', 'react-pdf'],
  
  // Add webpack configuration to handle react-pdf
  webpack: (config) => {
    // Add a rule to handle canvas in react-pdf
    config.resolve.alias.canvas = false;
    config.resolve.alias.encoding = false;
    
    return config;
  },
};

export default nextConfig;

