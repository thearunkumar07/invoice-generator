export interface InvoiceItem {
  description: string
  quantity: number
  unitPrice: number
}

export interface AdditionalCharge {
  description: string
  amount: number
}

export interface InvoiceData {
  invoiceNumber: string
  date: string
  dueDate: string
  clientName: string
  clientEmail: string
  clientAddress: string
  clientTaxId: string
  items: InvoiceItem[]
  additionalCharges: AdditionalCharge[]
  notes: string
  currency: string
  taxRate: number
  discountType: "percentage" | "flat"
  discountValue: number
}

export interface BrandingData {
  businessName: string
  businessEmail: string
  businessAddress: string
  businessPhone: string
  businessTaxId: string
  bankDetails: string
  logo: string | File | null
  primaryColor: string
  watermark: {
    enabled: boolean
    text: string
    opacity: number
    angle: number
  }
}

