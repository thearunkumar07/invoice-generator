import type { InvoiceData, BrandingData } from "@/types"
import { pdf } from "@react-pdf/renderer"
import InvoicePDFDocument from "@/components/InvoicePDFDocument"

interface ExportProps {
  invoiceData: InvoiceData
  brandingData: BrandingData
  subtotal: number
  discountAmount: number
  additionalChargesTotal: number
  tax: number
  total: number
  fileName: string
}

// Helper function to download a blob
function downloadBlob(blob: Blob, fileName: string) {
  // Create a URL for the blob
  const url = URL.createObjectURL(blob)

  // Create a temporary link element
  const link = document.createElement("a")
  link.href = url
  link.download = fileName

  // Append to the document, click it, and then remove it
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)

  // Clean up the URL object
  setTimeout(() => URL.revokeObjectURL(url), 100)
}

// Export as PDF
export async function exportAsPDF({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
  fileName,
}: ExportProps) {
  try {
    // Create the PDF document
    const document = InvoicePDFDocument({
      invoiceData,
      brandingData,
      subtotal,
      discountAmount,
      additionalChargesTotal,
      tax,
      total,
    })

    // Generate a blob from the PDF document
    const blob = await pdf(document).toBlob()

    // Download the file
    downloadBlob(blob, `${fileName}.pdf`)

    return true
  } catch (error) {
    console.error("Error generating PDF:", error)
    throw error
  }
}

// Export as JSON
export function exportAsJSON({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
  fileName,
}: ExportProps) {
  try {
    const data = {
      invoice: invoiceData,
      branding: {
        ...brandingData,
        // Convert logo to string if it's a File
        logo: typeof brandingData.logo === "string" ? brandingData.logo : null,
      },
      calculations: {
        subtotal,
        discountAmount,
        additionalChargesTotal,
        tax,
        total,
      },
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    downloadBlob(blob, `${fileName}.json`)

    return true
  } catch (error) {
    console.error("Error generating JSON:", error)
    throw error
  }
}

// Export as CSV
export function exportAsCSV({
  invoiceData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
  fileName,
}: ExportProps) {
  try {
    // Create header row
    let csv = "Description,Quantity,Unit Price,Amount\n"

    // Add item rows
    invoiceData.items.forEach((item) => {
      // Escape commas in description
      const escapedDescription = item.description.includes(",") ? `"${item.description}"` : item.description

      const amount = item.quantity * item.unitPrice
      csv += `${escapedDescription},${item.quantity},${item.unitPrice.toFixed(2)},${amount.toFixed(2)}\n`
    })

    // Add additional charges
    if (invoiceData.additionalCharges.length > 0) {
      csv += "\nAdditional Charges\n"
      csv += "Description,Amount\n"

      invoiceData.additionalCharges.forEach((charge) => {
        // Escape commas in description
        const escapedDescription = charge.description.includes(",") ? `"${charge.description}"` : charge.description

        csv += `${escapedDescription},${charge.amount.toFixed(2)}\n`
      })
    }

    // Add totals
    csv += "\nSummary\n"
    csv += `Subtotal,${subtotal.toFixed(2)}\n`
    if (discountAmount > 0) {
      csv += `Discount,${discountAmount.toFixed(2)}\n`
    }
    if (additionalChargesTotal > 0) {
      csv += `Additional Charges,${additionalChargesTotal.toFixed(2)}\n`
    }
    csv += `Tax (${invoiceData.taxRate}%),${tax.toFixed(2)}\n`
    csv += `Total,${total.toFixed(2)}\n`

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" })
    downloadBlob(blob, `${fileName}.csv`)

    return true
  } catch (error) {
    console.error("Error generating CSV:", error)
    throw error
  }
}

// Export as HTML
export function exportAsHTML({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
  fileName,
}: ExportProps) {
  try {
    // Format currency
    const formatCurrency = (amount: number) => {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: invoiceData.currency,
      }).format(amount)
    }

    // Create HTML content
    let html = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Invoice ${invoiceData.invoiceNumber}</title>
      <style>
        body {
          font-family: Arial, sans-serif;
          line-height: 1.6;
          color: #333;
          max-width: 800px;
          margin: 0 auto;
          padding: 20px;
        }
        .header {
          display: flex;
          justify-content: space-between;
          margin-bottom: 30px;
        }
        .business-info {
          margin-bottom: 20px;
        }
        .business-name {
          font-size: 24px;
          font-weight: bold;
          color: ${brandingData.primaryColor};
        }
        .invoice-info {
          background-color: #f5f5f5;
          padding: 15px;
          border-radius: 5px;
        }
        .client-info {
          margin-bottom: 30px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 20px;
        }
        th, td {
          padding: 10px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        th {
          background-color: #f5f5f5;
        }
        .text-right {
          text-align: right;
        }
        .totals {
          margin-left: auto;
          width: 300px;
        }
        .total-row {
          display: flex;
          justify-content: space-between;
          padding: 5px 0;
        }
        .grand-total {
          font-weight: bold;
          font-size: 18px;
          border-top: 2px solid #ddd;
          padding-top: 5px;
        }
        .notes, .payment {
          margin-top: 30px;
          border-top: 1px solid #ddd;
          padding-top: 20px;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="business-info">
          <div class="business-name">${brandingData.businessName || "Your Business Name"}</div>
          ${brandingData.businessAddress ? `<div>${brandingData.businessAddress}</div>` : ""}
          ${brandingData.businessEmail ? `<div>${brandingData.businessEmail}</div>` : ""}
          ${brandingData.businessPhone ? `<div>${brandingData.businessPhone}</div>` : ""}
          ${brandingData.businessTaxId ? `<div>GSTIN/VAT: ${brandingData.businessTaxId}</div>` : ""}
        </div>
        
        <div class="invoice-info">
          <h2 style="color: ${brandingData.primaryColor};">INVOICE</h2>
          <div><strong>Invoice Number:</strong> ${invoiceData.invoiceNumber || "INV-001"}</div>
          <div><strong>Date:</strong> ${invoiceData.date}</div>
          <div><strong>Due Date:</strong> ${invoiceData.dueDate}</div>
        </div>
      </div>
      
      <div class="client-info">
        <h3>Bill To:</h3>
        <div style="font-size: 18px; font-weight: bold;">${invoiceData.clientName}</div>
        ${invoiceData.clientEmail ? `<div>${invoiceData.clientEmail}</div>` : ""}
        ${invoiceData.clientAddress ? `<div>${invoiceData.clientAddress.replace(/\n/g, "<br>")}</div>` : ""}
        ${invoiceData.clientTaxId ? `<div>GSTIN/VAT: ${invoiceData.clientTaxId}</div>` : ""}
      </div>
      
      <table>
        <thead>
          <tr>
            <th>Description</th>
            <th class="text-right">Qty</th>
            <th class="text-right">Unit Price</th>
            <th class="text-right">Amount</th>
          </tr>
        </thead>
        <tbody>
    `

    // Add items
    invoiceData.items.forEach((item) => {
      const amount = item.quantity * item.unitPrice
      html += `
        <tr>
          <td>${item.description || "Item description"}</td>
          <td class="text-right">${item.quantity}</td>
          <td class="text-right">${formatCurrency(item.unitPrice)}</td>
          <td class="text-right">${formatCurrency(amount)}</td>
        </tr>
      `
    })

    html += `
        </tbody>
      </table>
    `

    // Add additional charges if any
    if (invoiceData.additionalCharges.length > 0) {
      html += `
        <h3>Additional Charges:</h3>
        <table>
          <tbody>
      `

      invoiceData.additionalCharges.forEach((charge) => {
        html += `
          <tr>
            <td>${charge.description || "Additional charge"}</td>
            <td class="text-right">${formatCurrency(charge.amount)}</td>
          </tr>
        `
      })

      html += `
          </tbody>
        </table>
      `
    }

    // Add totals
    html += `
      <div class="totals">
        <div class="total-row">
          <span>Subtotal:</span>
          <span>${formatCurrency(subtotal)}</span>
        </div>
    `

    if (discountAmount > 0) {
      html += `
        <div class="total-row" style="color: #e53e3e;">
          <span>Discount ${invoiceData.discountType === "percentage" ? `(${invoiceData.discountValue}%)` : ""}:</span>
          <span>-${formatCurrency(discountAmount)}</span>
        </div>
      `
    }

    if (additionalChargesTotal > 0) {
      html += `
        <div class="total-row">
          <span>Additional Charges:</span>
          <span>${formatCurrency(additionalChargesTotal)}</span>
        </div>
      `
    }

    html += `
        <div class="total-row">
          <span>Tax (${invoiceData.taxRate}%):</span>
          <span>${formatCurrency(tax)}</span>
        </div>
        
        <div class="total-row grand-total">
          <span>Total:</span>
          <span>${formatCurrency(total)}</span>
        </div>
      </div>
    `

    // Add bank details if available
    if (brandingData.bankDetails) {
      html += `
        <div class="payment">
          <h3>Payment Details:</h3>
          <pre style="font-family: inherit; white-space: pre-wrap;">${brandingData.bankDetails}</pre>
        </div>
      `
    }

    // Add notes if available
    if (invoiceData.notes) {
      html += `
        <div class="notes">
          <h3>Notes:</h3>
          <pre style="font-family: inherit; white-space: pre-wrap;">${invoiceData.notes}</pre>
        </div>
      `
    }

    // Close HTML
    html += `
    </body>
    </html>
    `

    const blob = new Blob([html], { type: "text/html;charset=utf-8" })
    downloadBlob(blob, `${fileName}.html`)

    return true
  } catch (error) {
    console.error("Error generating HTML:", error)
    throw error
  }
}

// Export as plain text
export function exportAsText({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
  fileName,
}: ExportProps) {
  try {
    // Format currency
    const formatCurrency = (amount: number) => {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: invoiceData.currency,
      }).format(amount)
    }

    // Create text content
    let text = `INVOICE\n\n`

    // Business info
    text += `${brandingData.businessName || "Your Business Name"}\n`
    if (brandingData.businessAddress) text += `${brandingData.businessAddress}\n`
    if (brandingData.businessEmail) text += `${brandingData.businessEmail}\n`
    if (brandingData.businessPhone) text += `${brandingData.businessPhone}\n`
    if (brandingData.businessTaxId) text += `GSTIN/VAT: ${brandingData.businessTaxId}\n`

    text += `\n`

    // Invoice info
    text += `Invoice Number: ${invoiceData.invoiceNumber || "INV-001"}\n`
    text += `Date: ${invoiceData.date}\n`
    text += `Due Date: ${invoiceData.dueDate}\n\n`

    // Client info
    text += `BILL TO:\n`
    text += `${invoiceData.clientName}\n`
    if (invoiceData.clientEmail) text += `${invoiceData.clientEmail}\n`
    if (invoiceData.clientAddress) text += `${invoiceData.clientAddress}\n`
    if (invoiceData.clientTaxId) text += `GSTIN/VAT: ${invoiceData.clientTaxId}\n`

    text += `\n`

    // Items
    text += `ITEMS:\n`
    text += `Description | Quantity | Unit Price | Amount\n`
    text += `${"-".repeat(60)}\n`

    invoiceData.items.forEach((item) => {
      const amount = item.quantity * item.unitPrice
      text += `${item.description || "Item description"} | ${item.quantity} | ${formatCurrency(item.unitPrice)} | ${formatCurrency(amount)}\n`
    })

    text += `\n`

    // Additional charges
    if (invoiceData.additionalCharges.length > 0) {
      text += `ADDITIONAL CHARGES:\n`
      text += `Description | Amount\n`
      text += `${"-".repeat(40)}\n`

      invoiceData.additionalCharges.forEach((charge) => {
        text += `${charge.description || "Additional charge"} | ${formatCurrency(charge.amount)}\n`
      })

      text += `\n`
    }

    // Totals
    text += `SUMMARY:\n`
    text += `Subtotal: ${formatCurrency(subtotal)}\n`

    if (discountAmount > 0) {
      text += `Discount ${invoiceData.discountType === "percentage" ? `(${invoiceData.discountValue}%)` : ""}: -${formatCurrency(discountAmount)}\n`
    }

    if (additionalChargesTotal > 0) {
      text += `Additional Charges: ${formatCurrency(additionalChargesTotal)}\n`
    }

    text += `Tax (${invoiceData.taxRate}%): ${formatCurrency(tax)}\n`
    text += `Total: ${formatCurrency(total)}\n\n`

    // Bank details
    if (brandingData.bankDetails) {
      text += `PAYMENT DETAILS:\n${brandingData.bankDetails}\n\n`
    }

    // Notes
    if (invoiceData.notes) {
      text += `NOTES:\n${invoiceData.notes}\n`
    }

    const blob = new Blob([text], { type: "text/plain;charset=utf-8" })
    downloadBlob(blob, `${fileName}.txt`)

    return true
  } catch (error) {
    console.error("Error generating text:", error)
    throw error
  }
}

