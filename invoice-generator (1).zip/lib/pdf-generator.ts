// This file is only imported dynamically on the client side
import type { InvoiceData, BrandingData } from "@/types"
import { pdf } from "@react-pdf/renderer"

// Import the PDF document component dynamically
import InvoicePDFDocument from "@/components/InvoicePDFDocument"

interface GeneratePDFProps {
  invoiceData: InvoiceData
  brandingData: BrandingData
  subtotal: number
  discountAmount: number
  additionalChargesTotal: number
  tax: number
  total: number
  fileName: string
}

export async function generatePDF({
  invoiceData,
  brandingData,
  subtotal,
  discountAmount,
  additionalChargesTotal,
  tax,
  total,
  fileName,
}: GeneratePDFProps) {
  try {
    // Create the PDF document
    const document = InvoicePDFDocument({
      invoiceData,
      brandingData,
      subtotal,
      discountAmount,
      additionalChargesTotal,
      tax,
      total,
    })

    // Generate a blob from the PDF document
    const blob = await pdf(document).toBlob()

    // Create a URL for the blob
    const url = URL.createObjectURL(blob)

    // Create a temporary link element
    const link = document.createElement("a")
    link.href = url
    link.download = `${fileName}.pdf`

    // Append to the document, click it, and then remove it
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    // Clean up the URL object
    setTimeout(() => URL.revokeObjectURL(url), 100)
  } catch (error) {
    console.error("Error generating PDF:", error)
    throw error
  }
}

